﻿/*
 * Created by SharpDevelop.
 * User: Alexander Petrovskiy
 * Date: 10/02/2012
 * Time: 12:16 a.m.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace UIAutomation
{
    /// <summary>
    /// Description of WizardCmdletBase.
    /// </summary>
    public class WizardCmdletBase : HasScriptBlockCmdletBase
    {
        public WizardCmdletBase()
        {
        }
    }
}
