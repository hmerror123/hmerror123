﻿/*
 * Created by SharpDevelop.
 * User: Alexander Petrovskiy
 * Date: 3/3/2012
 * Time: 5:36 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace UIAutomation.Commands
{
    using System;
    using System.Management.Automation;
    // using System.Runtime.InteropServices;
    using System.Windows.Automation;
    
    using System.Security.Principal;
    
    using System.Collections;
    using System.Collections.ObjectModel;

    
}