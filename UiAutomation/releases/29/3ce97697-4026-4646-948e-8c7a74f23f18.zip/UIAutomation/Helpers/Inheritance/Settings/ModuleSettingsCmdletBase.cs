﻿/*
 * Created by SharpDevelop.
 * User: Alexander Petrovskiy
 * Date: 4/2/2012
 * Time: 10:25 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace UIAutomation
{
    using System;
    
    /// <summary>
    /// Description of ModuleSettingsCmdletBase.
    /// </summary>
    public class ModuleSettingsCmdletBase : CommonCmdletBase
    {
        public ModuleSettingsCmdletBase()
        {
        }
    }
}
