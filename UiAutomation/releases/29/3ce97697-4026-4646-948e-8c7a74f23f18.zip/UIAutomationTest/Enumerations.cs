﻿/*
 * Created by SharpDevelop.
 * User: Alexander Petrovskiy
 * Date: 3/14/2012
 * Time: 12:54 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace UIAutomationTest
{
    public enum TimeoutsAndDelays
    {
        Control_Delay0 = 0,
        Control_Delay2000 = 2000,
        Control_Timeout0 = 0,
        Control_Timeout3000Delay500_Delay = 500,
        Control_Timeout3000Delay500_Timeout = 3000,
        Control_Timeout2000Delay4000_Delay = 4000,
        Control_Timeout2000Delay4000_Timeout = 2000,
        Control_Timeout6000Delay3000_Delay = 3000,
        Control_Timeout6000Delay3000_Timeout = 6000,
        Form_Delay0 = 0,
        Form_Delay1000 = 1000,
        Form_Delay2000 = 2000,
        Form_Delay2500 = 2500,
        Form_Delay3000 = 3000,
        Form_Delay4000 = 4000,
        Form_Delay5000 = 5000,
        Form_Delay11000 = 11000
    }
}