Sometimes we need to get exactly the first or the last child. There are Get-UIAControlFirstChild and Get-UIAControlLastChild cmdlets on service:
{code:powershell}
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAButton -Name 1 | Get-UIAControlParent | Get-UIAControlFirstChild | Read-UIAControlName;
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAButton -Name 1 | Get-UIAControlParent | Get-UIAControlLastChild | Read-UIAControlName;
{code:powershell}

Tags: TreeWalker.GetFirstChild, TreeWalker.GetLastChild