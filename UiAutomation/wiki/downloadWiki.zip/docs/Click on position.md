The Invoke-UIAcontrolClick cmdlet supports click on a certain position. Coordinates that the cmdlet consumes are in pixels. The X-coordinate increases from the left border of the control to the right one, the Y-coordinate grows from the top border to the bottom one.
{code:powershell}
# this hits right
Get-UIAWindow -pn calc | Get-UIAButton -Name 1 | Invoke-UIAControlClick -X 3 -Y 3;
# this too
Get-UIAWindow -pn calc | Get-UIAButton -Name [1-3](1-3) | Invoke-UIAControlClick -X 20 -Y 20;
# this hits outside the lower-right corner of the control
Get-UIAWindow -pn calc | Get-UIAButton -Name 1 | Invoke-UIAControlClick -X 30 -Y 30;
{code:powershell}
Click on position works similarly to any click the cmdlet performs: it hits the input control(s) if the control(s) has/have handle(s). If no, it searches up the hierarchy to the first control with handle, calculates the position and hits there.
As any click this cmdlet does, click on position
* returns the input by default
* does not guarantee that click was successful

Tags: ControlType.Window, ControlType.Button, SendMessage