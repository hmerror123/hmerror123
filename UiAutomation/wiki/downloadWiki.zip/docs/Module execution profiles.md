There is also an initial profiles or modes (experimental):

[uiautomation.mode](uiautomation.mode)::Profile

the value of [UIautomation.modes](UIautomation.modes) type.