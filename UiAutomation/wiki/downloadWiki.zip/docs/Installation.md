# How to install the module

## Prepare your system
### Install or run PowerShell
Please find out in the Internet how to get PowerShell for your system and how to run it. Here are the links to
* WMF 2.0: [http://support.microsoft.com/kb/968929/en](http://support.microsoft.com/kb/968929/en)
* WMF 3.0: [http://www.microsoft.com/en-us/download/details.aspx?id=34595](http://www.microsoft.com/en-us/download/details.aspx?id=34595)
### Set the execution policy
that is feasible for your needs:
# run PowerShell via "Run as Administrator"
# issue the following command:
{code:powershell}
Set-ExecutionPolicy Bypass
# or
Set-ExecutionPolicy RemoteSigned
# or
Set-ExecutionPolicy Unrestricted
{code:powershell}
### Load the module
by running the following command:
{code:powershell}
ipmo .\UIAutomation.dll
# or specify the full path to the library
ipmo C:\1\2\3\UIAutomation.dll
{code:powershell}
For general-purpose testing, the module can be placed in the following folder structure:
%userprofile%"\Documents\WindowsPowerShell\Modules\UIAutomation,
i.e. the full path to UIAutomation.dll would be:
%userprofile%"\Documents\WindowsPowerShell\Modules\UIAutomation\UIAutomation.dll
### How to check that all is OK
Run the following command
{code:powershell}
(gmo uia*).Name
(gmo uia*).ExportedCommands.Count
{code:powershell}
The output should contains the name of module and the number of cmdlet found (may vary depending on the module evolution):
{code:powershell}
UIAutomation
434
{code:powershell}
### How to automate loading the module
If you need to automate the process of loading the module, consider learning the topic "PowerShell profiles" and simply add to a profile you preferred to the ipmo line from samples above.
Follow, for example, the link [http://technet.microsoft.com/en-us/library/ee692764.aspx](http://technet.microsoft.com/en-us/library/ee692764.aspx)
The good post about profiles: [http://vmin.wordpress.com/2012/05/28/understanding-the-six-powershell-profiles-technet-blogs](http://vmin.wordpress.com/2012/05/28/understanding-the-six-powershell-profiles-technet-blogs)

Note, for most applications you'll never need to run PowerShell as Administrator. However sometimes, for example for testing services.msc, you need to run it as Run As Administrator or under domain admin credentials)