There are two ways to invoke a context menu:
the Invoke-UiaControlContextMenu cmdlet
{code:powershell}
$element | Invoke-UiaControlContextMenu | Get-UiaMenuItem -Name ....
{code:powershell}
and the InvokeContextMenu method shown here [the Control property](the-Control-property).
{code:powershell}
$element.Control.InvokeContextMenu() | Get-UiaMenuItem -Name ....
{code:powershell}