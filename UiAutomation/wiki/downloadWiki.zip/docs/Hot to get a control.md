## from point
There is the Get-UIAControlFromPoint cmdlet:
{code:powershell}
Get-UIAControlFromPoint;
{code:powershell}