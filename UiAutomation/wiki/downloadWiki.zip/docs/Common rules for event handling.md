There are several rules and recommendation that should help you start using Automation events.
# register for as many events as necessary. Events are resource and time consumers.
# unregister all or some events as quickly as possibly ( the Unregister-UIAEvent cmdlet).
# you can access registered event via the static collection {"[UIAutomation.CurrentData](UIAutomation.CurrentData)::Events"} (this collection' content is what the Get-UIARegisteredEvent cmdlet returns)
# GUI event work on the GUI thread. This means that a range of features tied to the PowerShell thread could became unavailable (for example, the Write-Host cmdlet).

Events that MS UI Automation provides listed [here](http://msdn.microsoft.com/en-us/library/ms748252.aspx).
AutomationElement.AsyncContentLoadedEvent
SelectionItemPattern.ElementAddedToSelectionEvent
SelectionItemPattern.ElementRemovedFromSelectionEvent
SelectionItemPattern.ElementSelectedEvent
SelectionPattern.InvalidatedEvent
InvokePattern.InvokedEvent
AutomationElement.LayoutInvalidatedEvent
AutomationElement.MenuClosedEvent
AutomationElement.MenuOpenedEvent
TextPattern.TextChangedEvent
TextPattern.TextSelectionChangedEvent
AutomationElement.ToolTipClosedEvent
AutomationElement.ToolTipOpenedEvent
WindowPattern.WindowOpenedEvent
AutomationElement.AutomationFocusChangedEvent
AutomationElement.AutomationPropertyChangedEvent
AutomationElement.StructureChangedEvent
WindowPattern.WindowClosedEvent
For deeper understanding how MS UI Automation work and can be used, refer to the [link](http://msdn.microsoft.com/en-us/library/ms752297.aspx).