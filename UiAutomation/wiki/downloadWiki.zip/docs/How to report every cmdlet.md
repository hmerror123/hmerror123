

This page will tell you about the [UIAutomation.Preferences](UIAutomation.Preferences)::EveryCmdletAsTestResult parameter.