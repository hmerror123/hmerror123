Controls that are situated at the same level of the Automaiton tree as the input control (and called siblings) can be obtained with the help of Get-UIAControlNextSibling and Get-UIAControlPreviousSibling cmdlets:
{code:powershell}
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAButton -Name 1 | Get-UIAControlNextSibling | Read-UIAControlName;
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAButton -Name 1 | Get-UIAControlNextSibling| Get-UIAControlNextSibling | Read-UIAControlName;
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAButton -Name 1 | Get-UIAControlNextSibling| Get-UIAControlPreviousSibling | Read-UIAControlName;
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAButton -Name 1 | Get-UIAControlPreviousSibling | Read-UIAControlName;
{code:powershell}