In rare cases, an element could obtain or lost support for some pattern. This is a rare situation, a control or a window is reconfigured by the application under test or even rebuilt.
To refresh the elements' object model (add/3\remove actual properties and methods) there are method Refresh:
{code:powershell}
$element = $element.Refresh();
{code:powershell}