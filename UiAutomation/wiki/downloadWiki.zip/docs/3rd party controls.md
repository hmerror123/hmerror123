There will be a more consistent text.
Now, let's look at this [discussion](https://uiautomation.codeplex.com/workitem/9).