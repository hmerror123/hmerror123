The Descendants property returns all control of the selected type down the hierarchy:
{code:powershell}
$wnd = Start-Process calc -PassThru | Get-UiaWindow
$wnd.Descendants.Buttons
{code:powershell}
The oupput type is collection, so that to get a single control or several controls we need to feed the expression with numeric values:
{code:powershell}
$wnd.Descendants.Buttons[0](0)
$wnd.Descendants.Buttons[5..8](5..8)
{code:powershell}
or a fragment of their Name, AutomationId or ClassName properties
{code:powershell}
# only numeric button
# through their AutomationIds
$wnd.Descendants.Buttons['13*']('13_') | Read-UiaControlName
{code:powershell}

