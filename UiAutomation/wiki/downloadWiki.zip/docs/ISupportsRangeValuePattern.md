Interface ISupportsRangeValuePattern provides one writeble property RangeValue and five read-only properties:
{code:powershell}
# getting and setting the current value
$element.RangeValue
$element.RangeValue = 50

# getting properties
$element.IsRangeReadOnly
$element.Maximum
$element.Minimum
$element.LargeChange
$element.SmallChange
{code:powershell}