## Above the input object
[Getting the parent](Getting-the-parent)
[Getting ancestors](Getting-ancestors)
## Below the input object
[Getting children](Getting-children)
[Getting descendants](Getting-descendants)
[Getting first and last children](Getting-first-and-last-children)
## At the same level
[Getting siblings](Getting-siblings)