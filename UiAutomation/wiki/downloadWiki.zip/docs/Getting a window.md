Typical ways to obtain access to windows and controls (please note that you must run PowerShell as Administrator if you are not a domain admin or the settings don't allow you to) are as follow:

Get a window by its process name:
{code:powershell}
Get-UIAWindow -ProcessName $processname | Get-UIAButton -Name $btnName | Invoke-UIAButtonClick;
Get-UIAWindow -pn $processname | Get-UIAButton -Name $btnName | Invoke-UIAButtonClick;
Get-UIAWindow -ProcessName $processname | Get-UIAMenuItem -Name File | Invoke-UIAMenuItemClick | Get-UIAMenuItem -Name Open... | Invoke-UIAMenuItemClick | Get-UIAChildWindow -Name 'Open File'
{code:powershell}

Get a window by its process's Id:
{code:powershell}
Get-UIAWindow -ProcessId (Get-Process -Name mmc).Id
Get-UIAWindow -pid (Get-Process -Name mmc).Id
{code:powershell}

Get a window from process:
{code:powershell}
Start-Process calc -PassThru | Get-UIAWindow
Get-UIAWindow -Process (Get-Process -Name mmc)
Get-UIAWindow -p (Get-Process -Name mmc)
{code:powershell}

Get a window by window title:
{code:powershell}
Get-UIAWindow -Name $windowTitle | Get-UIAChildWindow | Get-UIATextBox -AutomationID ServerBox | Set-UIATextBoxText -Text "text";
{code:powershell}

Get a window by window handle:
{code:powershell}
Get-UIAWindowFromHandle -Handle 123456
{code:powershell}

Get the active window (it's recommended to run your script in a minimized window):
{code:powershell}
Get-UIAActiveWindow
{code:powershell}

There are two ways to access the window object to use elements' object model. The first is via explicit assigning the window object to a variable:
{code:powershell}
$wnd = Start-Process calc -PassThru | Get-UiaWindow
$wnd.Move(1000, 300);
{code:powershell}
and the second is via implicit assigning:
{code:powershell}
(Start-Process calc -PassThru | Get-UiaWindow).Move(1000, 300);
{code:powershell}
There are no IDE (at least, I don't know such) in the PowerShell world that are able to provide Intellisense over any braces, so that the latter way to use is for those who have already experienced with methods and properties that the object model provides with.

More information about the object model could be found at [Object model](Object-model).

Tags: ControlType.Window