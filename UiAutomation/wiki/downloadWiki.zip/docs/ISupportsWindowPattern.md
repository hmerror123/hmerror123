Interface ISupportsWindowPattern exposes a bunch of methods and properties:
{code:powershell}
$element.SetWindowVisualState([System.Windows.Automation.WindowVisualState](System.Windows.Automation.WindowVisualState)::Maximized);
$element.Close();
$element.WaitForInputIdle($milliseconds);

$element.CanMaximize
$element.CanMinimize
$element.IsModal
$element.IsTopmost
[System.Windows.Automation.WindowInteractionState](System.Windows.Automation.WindowInteractionState)$interactionState = $element.WindowInteractionState // may not be working
[System.Windows.Automation.WindowVisualState](System.Windows.Automation.WindowVisualState)$visualState = $element.WindowVisualState // may not be working
{code:powershell}