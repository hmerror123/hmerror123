It's a frequently asked question, where is the "some name" cmdlet?
Creating the full matrix of cmdlets (i.e. every pattern for every control type) is not an arduous task (though, arguable). However, we took the [Control Pattern Mapping for UI Automation Clients](http://msdn.microsoft.com/en-us/library/ms750574.aspx) document as a general rule and added the full spectrum of patterns to the Custom type only.

There we should say that the vast majority of cmdlets are in fact aliases. Preferebly, 'smart' aliases.
For example, the Invoke-UIAButtonClick cmdlet is an alias for the Invoke-UIAInvokePattern cmdlet. To illustrate this, look at the following code:
{code:powershell}
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAButton -Name 1 | Invoke-UIAButtonClick;
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAButton -Name 1 | Invoke-UIAInvokePattern;
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAButton -Name 1 | Invoke-UIAMenuItemClick;
{code:powershell}
These three lines of code do absolutely the same thing: run a process, get its window, get a button, and activate InvokePattern. The answer is that InvokeUIAButtonClickCommand and InvokeUIAMenuItemClickCommand derive from InvokeUIAInvokePatternCommand (to put simply, Invoke-UIAButtonClick and Invoke-UIAMenuItemClick are aliases for Invoke-UIAInvokePattern).

Another example is Get- cmdlets: the Get-UIAButton cmdlet is an alias for the following line of code:
{code:powershell}
Get-UIAControl -ControlType Button;
{code:powershell}
Derivations can be easily seen in PowerShell by using tab-autocomplete (PS 3.0):
{code:powershell}
[UIAutomation.Commands.GetUIAButtonCommand](UIAutomation.Commands.GetUIAButtonCommand)
{code:powershell}
The idea is that you can use parent cmdlets and sometimes sibling cmdlets in case you are missing a 'cmdlet with the right name'. You lose readability in one line of code - not a great cost.