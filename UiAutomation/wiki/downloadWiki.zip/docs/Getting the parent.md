The Get-UIAControlParent cmdlet returns the parent of the control that was pipelined into the cmdleet.
{code:powershell}
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAButton -Name 1 | Get-UIAcontrolParent | Read-UIAControlType;
{code:powershell}

Tags: TreeScope.Parent