[Creating an RDP session](Creating-an-RDP-session) TBD
[Unattended execution](Unattended-execution) TBD
[Execution via powerslim](Execution-via-powerslim) TBD