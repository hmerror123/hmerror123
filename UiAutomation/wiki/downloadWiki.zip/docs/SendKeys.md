There are tow ways to put a text in a control. Using out testeditbox application, we are going to perform this without using the pattern. There are two ways to put text in: Set-UIAControlText and Set-UIAControlKeys.
The first method works through the SendMessage API call. It should work pretty well as it sends to a handle.
{code:powershell}
Get-UIAWindow -n testeditbox | Get-UIAEdit | Set-UIAControlText "text2";
{code:powershell}
The second is .NET SendKeys.
The problem is that SendKeys sends only to the focused control. To avoid this issue, we will use setting the focus on a control and putting text in the control that contains focus.
{code:powershell}
Get-UIAWindow -n testeditbox | Get-UIAEdit | Set-UIAFocus;
Get-UIAEdit | Set-UIAControlKeys "text2";
{code:powershell}
![](SendKeys_SendKeys004.jpg)
Get-UIAWindow -n testeditbox | Get-UIAEdit | Set-UIAFocus;
Get-UIAEdit | Set-UIAControlKeys "^(A){DELETE}";
{code:powershell}
![](SendKeys_SendKeys005.jpg)

Step by step guide:
1) get a control
2) set focus
3) get a control again (the Set-UIAControlKeys requires input), the control is foreground now
4) put keys to the control (Ctrl+A and Delete).

If your control of some other sort, you may need to do other tricks. Nonetheless, the idea behind is as I demonstrated.