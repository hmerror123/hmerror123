Taken, as an example, a simple Windows Forms application called ‘testeditbox’ with a label and a text box.
![](ValuePattern_SendKeys001.jpg)
We can write in and, after, clean it the following way:
{code:powershell}
Get-UIAWindow -n testeditbox | Get-UIAEdit | Set-UIAEditText texttexttext;
{code:powershell}
![](ValuePattern_SendKeys002.jpg)
{code:powershell}
Get-UIAWindow -n testeditbox | Get-UIAEdit | Set-UIAEditText "";
{code:powershell}
![](ValuePattern_SendKeys003.jpg)