Interface ISupportsScrollPattern exposes a bunch of methods and properties:
{code:powershell}
$element.SetScrollPercent($horizontalPercent, $verticalPercent);
$horizontalAmount = [System.Windows.Automation.ScrollAmount](System.Windows.Automation.ScrollAmount)::LargeIncrement;
$verticalAmount = [System.Windows.Automation.ScrollAmount](System.Windows.Automation.ScrollAmount)::SmallDecrement;
$element.Scroll($horizontalAmount, $verticalAmount);
$element.ScrollHorizontal($horizontalAmount);
$element.ScrollVertical($verticalAmountt);
		
$element.HorizontalScrollPercent
$element.VerticalScrollPercent
$element.HorizontalViewSize
$element.VerticalViewSize
$element.HorizontallyScrollable
$element.VerticallyScrollable
{code:powershell}