Interface ISupportsGridPattern exposes method GetItem and two properties:
{code:powershell}
$grid = Get-UiaDataGrid;

# getting an item by row and co.un numbers
$firstElement = $grid.GetItem(0, 0);
$element = $grid.GetItem(3, 3);

# getting counters
$grid.GridRowCount
$grid.GridColumnCount
{code:powershell}