This tutorial will use charmap.exe that is installed by default on Windows 8. On previous systems or on servers you may need to install this feature manually.
![](Check Boxes_Charmap001.jpg)
## Getting state
{code:powershell}
Start-Process charmap -PassThru | Get-UIAWindow | Get-UIACheckBox | Get-UIACheckBoxToggleState;
{code:powershell}
## Setting 'checked' and 'unchecked'
The same code checks and unchecks a check box:
{code:powershell}
Start-Process charmap -PassThru | Get-UIAWindow | Get-UIACheckBox | Invoke-UIACheckBoxToggle;
{code:powershell}
![](Check Boxes_Charmap002.jpg)
Tags: ControlType.Window, ControlType.CheckBox, TogglePattern