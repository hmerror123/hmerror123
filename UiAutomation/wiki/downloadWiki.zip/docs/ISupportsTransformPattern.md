Interface ISupportsTransformPattern exposes the following methods and properties:
{code:powershell}
$element.Move($x, $y);
$element.Resize($width, $height);
$element.Rotate($degrees);

$element.CanMove
$element.CanResize
$element.CanRotate
{code:powershell}