How to program a wizard test? Write several functions like below which do some logic and press the Next button?
{code:powershell}
function Invoke-WelcomeStep {
    if ((Wait-UIAWindow -n **wizard** -WithControl @{name="**welcome**"})) {
        $null = Get-UIAButton -Name **Next** | Invoke-UIAButtonClick;
    }
}

function Invoke-LicenseeAgreementStep {
    if ((Wait-UIAWindow -n **wizard** -WithControl @{name="**accept**"})) {
        $null = Get-UIACheckBox -Name **accept** | Set-UIACheckBoxToggleState $true;
        $null = Get-UIAButton -Name **Next** | Invoke-UIAButtonClick;
    }
}
{code:powershell}
These days, we have a specific set of cmdlets for such use. Here is the list:

**New-UIAWizard** - creates a new wizard object, gives it the name and initial script (Start-Process of an independent wizard-application or click anywhere in the program to call an embedded wizard)

**Add-UIAWizardStep** - takes the wizard object through the pipeline (or the InputObject parameter), sets the name to a step. After that adds the step to the wizard.

**Remove-UIAWizardStep** - removes a step from the collection

**Get-UIAWizard** - returns a wizard by name

**Invoke-UIAWizard** - starts the wizard by running code in the start action, returns the wizard object.

The Step-UIAWizard cmdlet is now obsolete.