In this exercise, we will use UIA Verify as a guide. UIA Verify demonstrates graphically how controls are placed in the Automation tree.
Let's run calc.exe and learn in detail how to get a button via pipeline. We are going to get the root of the system menu that can be called by pressing Alt+Space.
![](Pipelining controls_Pipeline001.jpg)
The code below follows numbers that are on the picture:
{code:powershell}
ipmo UIAutomation;
Get-UIAWindow -pn calc | Get-UIATitleBar | Get-UIAMenuBar | Get-UIAMenuItem | Read-UIAControlName;
{code:powershell}
This example shows how to get a control that is in parent-child relation to the previous one. 
There is usually no need to write the full path, from control to control. This example does exactly the same the previous example did:
{code:powershell}
Get-UIAWindow -pn calc | Get-UIAMenuItem -Name System | Read-UIAControlName;
{code:powershell}
There is, however, no silver bullet in this choice: how many controls should be in the chain before we get successfully the control we're hunting down. Sometimes, it's enough to run code like
{code:powershell}
Get-UIAWindow | Get-UIA[TargetControl](TargetControl)
{code:powershell}
in some situations, we should direct the search in a certain direction:
{code:powershell}
Get-UIAWindow | Get-UIA[SomeAnchorControl](SomeAnchorControl) | Get-UIA[AnotherAnchor](AnotherAnchor) | Get-UIA[TargetControl](TargetControl)
{code:powershell}
In practice, we may need to get controls that are of a certain type and placed in a certain part of GUI, regardless names or automation ids.
Let's get menu items. The evident way is to run the following piece of code:
{code:powershell}
Get-UIAWindow -pn calc | Get-UIAMenuItem | Read-UIAControlName
{code:powershell}
The output consists of four menu items, three of them are what we were looking for (View, Edit, Help) and the fourth is what we have been playing around the first part of this tutorial. How to separate the first group of menu items (View, Edit, Help) from the System menu item?
Knowing their names, it's extremely easy:
{code:powershell}
Get-UIAWindow -pn calc | Get-UIAMenuItem -Name [veh](veh)* | Read-UIAControlName;
{code:powershell}
But what can we do if the app under test is localized or we aren't aware of names of controls, or controls simply does not have names? We need an anchor to direct our search in the right direction and bind the search to a certain location in the Automation tree.
![](Pipelining controls_Pipeline002.jpg)
After having looked at the Automation tree, we know the answer: the menu bar 'Application' is our anchor.
{code:powershell}
Get-UIAWindow -pn calc | Get-UIAMenuBar -Name Applic* | Get-UIAMenuItem | Read-UIAControlName;
{code:powershell}
We are jumping to the menu bar and getting three and only three menu items, regardless their names. Great! This code will survive localization as the name of menu bar is not what the user sees (and therefore, it won't be changed during the localization).

Tags: ControlType.Window, ControlType.TitleBar, ControlType.MenuBar, ControlType.MenuItem