Interface ISupportsTextPattern exposes four methods and one property (some of them are NOT YET IMPLEMENTED):
{code:powershell}
$ranges = $element.GetTextSelection();
$ranges = $element.GetVisibleRanges();
$range = $element.RangeFromChild($childElement);
# $range = $element.RangeFromPoint(Point screenLocation);
[System.Windows.Automation.Text.TextPatternRange](System.Windows.Automation.Text.TextPatternRange)$range = $element.DocumentRange
[System.Windows.Automation.SupportedTextSelection](System.Windows.Automation.SupportedTextSelection)$textSelection = $element.SupportedTextSelection
{code:powershell}