The example demonstrates how to move a tree item of a certain type into another tree item of the type 'folder' (in terms of an application under test).
The action consists of three steps:
- getting the first control and pressing the Left button
- moving the cursor over the first control with the Left button pressed
- moving the control to the second control and releasing the Left button
the two seconds' sleep is for the application under test (it reconfigures real-life objects the same time we move the cursor), you might not nned the sleep.
{code:powershell}
$treeItem01 = Get-UiaTreeItem -Name **comp**coll**
$treeItem02 = Get-UiaTreeItem -Name **folder**

$treeItem01 | Invoke-UiaControlClick; # step 1
$treeItem01.Mouse.LeftButtonDown();
$treeItem01 | Move-UiaCursor -X 5 -Y 5; # step 2
$treeItem02 | Move-UiaCursor -X 5 -Y 5; # step 3
$treeItem02.SetFocus();
sleep -Seconds 2;
$treeItem02.Mouse.LeftButtonUp();
{code:powershell}