[More information about the module](More-information-about-the-module)
Documentation in a file, blog posts, how to contact us, etc

## Installation and valuable tools for UI automation
[Installation](Installation)
[Installation for Metro UI testing](Installation-for-Metro-UI-testing)
[Installation for Java SWT applications testing](Installation-for-Java-SWT-applications-testing) TBD
[Installation for remote execution](Installation-for-remote-execution) TBD
[How to find the proper commandlet](How-to-find-the-proper-commandlet)
[Valuable tools](Valuable-tools) - free and complimentary tools that are helpful in UI automation
[UIAutomationSpy](UIAutomationSpy) TBD
[UIARunner](UIARunner) in progress
[OnDemandRunner](OnDemandRunner) TBD
[BGShell for Metro UI testing](BGShell-for-Metro-UI-testing) TBD

## Getting started
[Getting a window](Getting-a-window)
[Getting a control](Getting-a-control)
[Pipelining controls](Pipelining-controls)
[Invoking actions on controls](Invoking-actions-on-controls) in progress
Invoking actions on controls via [Object model](Object-model)
[Checking the state of UI](Checking-the-state-of-UI)
[Top-level objects](Top-level-objects)
[Context menus](Context-menus)
[Drag and drop](Drag-and-drop)

## More on working with controls
[Object model](Object-model)
[Controls](Controls) in progress
Clicks: [the Control property](the-Control-property), [the Mouse property](the-Mouse-property), [Clicks](Clicks)
Keyboard emulation: [the Keyboard property](the-Keyboard-property)
[Text: reading from and writing to](Text_-reading-from-and-writing-to) in progress
[Navigation among controls](Navigation-among-controls)
[3rd party controls](3rd-party-controls)

## Event handling
[Common rules for event handling](Common-rules-for-event-handling)
[Invoked event](Invoked-event)
[FocusChanged event](FocusChanged-event) TBD
[WindowOpened and WindowClosed events](WindowOpened-and-WindowClosed-events) TBD
[MenuOpened and MenuClosed events](MenuOpened-and-MenuClosed-events)
[TooltipOpened and TooltipClosed](TooltipOpened-and-TooltipClosed)
[StructureChanged events](StructureChanged-events)
[PropertyChanged event](PropertyChanged-event) TBD
[TextChanged and TextSelectionChanged events](TextChanged-and-TextSelectionChanged-events) TBD
[SelectionItemPattern events](SelectionItemPattern-events) TBD
[SelectionPattern events](SelectionPattern-events) TBD

## Additional capabilities
[Screenshot hooks](Screenshot-hooks) in progress
[Custom hooks](Custom-hooks) TBD
[Logging](Logging)
[Error collection](Error-collection) TBD
[Delays](Delays) TBD
[Graphical trace](Graphical-trace) TBD

## Applications, frameworks, libraries that we support
[Win32 sample](Win32-sample) TBD
[Windows Forms sample](Windows-Forms-sample) TBD
[WPF sample](WPF-sample) TBD
[Metro UI (WinRT) app sample](Metro-UI-(WinRT)-app-sample) TBD
[Java SWT sample](Java-SWT-sample) TBD
[Qt application samples](Qt-application-samples) TBD
[PowerBuilder 12.5 samples](PowerBuilder-12.5-samples) TBD
[Command tabs](Command-tabs) TBD

## Sample scenarios
[Standard Windows application](Standard-Windows-application) TBD
[WPF application](WPF-application) TBD
[Metro UI application](Metro-UI-application) TBD
[Web page](Web-page) TBD

## Specific use
[The **Wizard** cmdlets](The-__Wizard__-cmdlets)
The legacy version of the **Wizard** cmdlets [http://uiautomation.codeplex.com/wikipage?title=%2aWizard%2a%20cmdlets](http://uiautomation.codeplex.com/wikipage?title=%2aWizard%2a%20cmdlets)

## Continous integration with UIAutomation tests
[Common concerns](Common-concerns)
[Jenkins sample](Jenkins-sample) TBD
[TeamCity sample](TeamCity-sample) TBD
[CruiseControl.NET sample](CruiseControl.NET-sample) TBD

## Software testing extensions
[Reporting about your tests](Reporting-about-your-tests) (to be rewritten) - with or without TMX you are able to manipulate your test results
[How to report every cmdlet](How-to-report-every-cmdlet) TBD
[How to interrupt test execution](How-to-interrupt-test-execution) TBD
[Speeding up test flow on a specific fail](Speeding-up-test-flow-on-a-specific-fail) TBD

## Module settings and data
[Module settings](Module-settings) (in progress) - the list of available settings
[Module execution profiles](Module-execution-profiles) (to be rewritten) - you can attach settings to a certain objects or code in your scripts
[Collected data](Collected-data) (to be rewritten) - some data are stored for immediate or future use

## Troubleshooting guide
["Could not get a control"](_Could-not-get-a-control_) TBD
["Hot to get a control"](_Hot-to-get-a-control_) TBD
["It does not click"](_It-does-not-click_) TBD
["How to click ..."](_How-to-click-..._) TBD
["How to do"](_How-to-do_) TBD
["There's no such cmdlet as I need to"](_There's-no-such-cmdlet-as-I-need-to_)

## Release history
[Release history](Release-history)