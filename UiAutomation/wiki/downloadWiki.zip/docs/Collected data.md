Collected data can be obtained through the

[UIAutomation.CurrentData](UIAutomation.CurrentData)

static class.