## Introduction
All our test frameworks (UIAutomation, SePSX, TMX, etc) are made up, of course, with reporting in mind. There are two ways to report results of your tests:
* rich reporting capabilities with the TMX module
* basic reporting via out-of-the-box TMX.dll
Whereas TMX as a module provides you with such capabilities as sorting and filtering of test results, writing them to and reading from a database, etc, TMX as an embedded library enables you to have your test results as a list.
This article is about the second case.
## Examples
How to use primitive reporting? All cmdlets have special common parameters:
* -TestResultName (a string that helps you recognize a certain test result)
* -TestPassed (a switch parameters that declares a test result as Passed or Failed (-TestResult:$false))
* -KnownIssue (during working on a version of the product, the situation when test are written but product coudn't keep up is not rare. When it's considered 'not a bug', for example, 'not implemented' or 'postponed', the -KnownIssue parameter marks the result as KnownIssue).
Alternatively, you can use automated test result generation:
{code:powershell}
[UIAutomation.Preferences](UIAutomation.Preferences)::EveryCmdletAsTestResult = $true
{code:powershell}
We would recommend to generate test results automatically in most cases, and only in cases you need a specific logic to make a test result decision to use hand=made test results.
{code:powershell}
ipmo UIAutomation;
[UIAutomation.Preferences](UIAutomation.Preferences)::EveryCmdletAsTestResult=$true

# the happy path
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAButton -Name 1 | Invoke-UIAButtonClick;

# code that never be marked as Passed:
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAButton -Name 10 | Invoke-UIAButtonClick;

[TMX.TestData](TMX.TestData)::CurrentTestScenario.TestResults | fl name,status,timespent
{code:powershell}
In the above example, names of test results are generated from code.



# This is under rewriting

{code:powershell}
[UIAutomation.Preferences](UIAutomation.Preferences)::EveryCmdletAsTestResult = $true
Start-Process calc -PassThru | Get-UIAWindow -TestResultName "Calculator started" | Get-UIAButton -Name 1 -TestResultName "The Button 1 has been found" | Invoke-UIAButtonClick -TestResultName "The Button 1 has been clicked"
[TMX.TestData](TMX.TestData)::CurrentTestScenario.TestResults | fl name,status,timespent
{code:powershell}

{code:powershell}
Get-UIAWindow -Name $windowTitle | Get-UIAChildWindow | Get-UIATextBox -AutomationID ServerBox | Set-UIATextBoxText -OnSuccessAction {Set-UIATestResultLabel -TestResultLabel "1.1.1" -TestPassed} -OnErrorAction {Set-UIATestResultLabel -TestResultLabel "1.1.1"}
{code:powershell}
{code:powershell}
Get-UIAWindow -ProcessName $processname | Get-UIADataGrid | Invoke-UIAControlContextMenu | Get-UIAMenuItem -Name Properties;
Add-UIATestDetail -TestDetail "Properties window: test started";

# code

Add-UIATestDetail -TestDetail "Properties window: test almost passed, the final click";

# code

If (-not (Get-UIAWindow -ProcessName $processname | Get-UIAChildWindow -Name Properties)){

Set-UIATestResultLabel -TestResultLabel "1.1.2";

} else {

Set-UIATestResultLabel -TestResultLabel "1.1.2" -TestPassed

}
{code:powershell}
visit the [uiautomation.currentdata](uiautomation.currentdata)::TestResults collection to look at your test's results.