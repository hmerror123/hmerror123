[UIAutomation.Preferences](UIAutomation.Preferences)::HideHighlighterOnScreenShotTaking
True
[UIAutomation.Preferences](UIAutomation.Preferences)::OnErrorScreenShot
True
[UIAutomation.Preferences](UIAutomation.Preferences)::OnErrorScreenShotFormat

Guid
----
b96b3cae-0728-11d3-9d7b-0000f81ef32e


[UIAutomation.Preferences](UIAutomation.Preferences)::OnSuccessScreenShot
False
[UIAutomation.Preferences](UIAutomation.Preferences)::OnSuccessScreenShotFormat

Guid
----
b96b3cae-0728-11d3-9d7b-0000f81ef32e


[UIAutomation.Preferences](UIAutomation.Preferences)::ScreenShotFolder
C:\Users\shuran\AppData\Local\Temp
