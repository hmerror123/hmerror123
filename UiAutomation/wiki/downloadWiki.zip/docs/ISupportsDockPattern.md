Interface ISupportsDockPattern exposes the DockPosition property
{code:powershell}
$dockable.DockPosition;
{code:powershell}
 and the SetDockPosition method.
{code:powershell}
$dockable.SetDockPosition([System.Windows.Automation.DockPosition](System.Windows.Automation.DockPosition)::Bottom);
{code:powershell}
