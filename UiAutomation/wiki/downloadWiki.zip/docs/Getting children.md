The Get-UIAControlChildren cmdlet returns all controls that are one level below of the input control:
{code:powershell}
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAControlChildren | %{ Write-Host $_.Current.ControlType.ProgrammaticName $_.Current.Name $_.Current.AutomationId; }
{code:powershell}

Tags: TreeScope.Children