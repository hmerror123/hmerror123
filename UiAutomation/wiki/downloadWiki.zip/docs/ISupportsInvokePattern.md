Interface ISupportsInvokePattern exposes one method:
{code:powershell}
$element.Invoke();
{code:powershell}