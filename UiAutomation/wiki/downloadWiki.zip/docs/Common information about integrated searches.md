There are two goals the extended elements' object model should achieve:
1) provide the use with an overview what controls are available down the hierarchy
2) simplify coding in certain situations via dotted notation.

To get an overview of controls that are under the current, we simply call a collection:
{code:powershell}
$wnd = Start-Process calc -PassThru | Get-UiaWindow;
$wnd.Descendants.Buttons
{code:powershell}
We couldn't use $wnd.Children here as no one button is immediately under the window object. Technically, we could, but the line $wnd.Children.Buttons returns $null, of course.

To get a brief overview of all types of controls available down the hierarchy, we can simply call the list of collections (it may take time if an application is heavily loaded with controls as an app with grids, lists, etc):
{code:powershell}
$wnd = Start-Process calc -PassThru | Get-UiaWindow;
$wnd.Children
$wnd.Descendants
{code:powershell}

Getting a collection is not the only feature of the extended elements' object model. We could easily select controls of our interest by using a part of their Name, AutomationId or Class:
{code:powershell}
$wnd = Start-Process calc -PassThru | Get-UiaWindow;

# returns two buttons, Maximize and Minimize
$wnd.Descendants.Buttons['*ize']('_ize')

# narrowing the selection to the Maximize button only
$wnd.Descendants.Buttons['**ize']('__ize')['Max**']('Max__')
{code:powershell}
This sample is not very clear as we user here the same property, Name.

The next sample demonstrates how to get buttons by using AutomationId and Name subsequently:
{code:powershell}
$wnd = Start-Process calc -PassThru | Get-UiaWindow;

# there are ten numeric buttons with AutomationId 13*, from 1 to 10 (or 0 to 9 depending on localization):
$wnd.Descendants.Buttons['13*']('13_').Count

# getting the button 2:
$wnd.Descendants.Buttons['13*']('13_')['2']('2')

# we can check that 2 is 2 by outputting the result:
$wnd.Descendants.Buttons['13*']('13_')['2']('2') | Read-UiaControlName
# or
$wnd.Descendants.Buttons['13*']('13_')['2']('2').Current
{code:powershell}
The same sample via a variable:
{code:powershell}
$wnd = Start-Process calc -PassThru | Get-UiaWindow;

# getting numeric buttons
$numericButtons = $wnd.Descendants.Buttons['13*']('13_')

# getting the button 2
$numericButtons['2']('2')
{code:powershell}