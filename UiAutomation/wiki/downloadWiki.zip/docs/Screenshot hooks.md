By default, the module saves a screenshot on every fail of a cmdlet:
{code:powershell}
[UIAutomation.Preferences](UIAutomation.Preferences)::OnErrorScreenShot
# default: $true
{code:powershell}
The default format is jpeg and you can change the format as shown in the following example:
{code:powershell}
[UIAutomation.Preferences](UIAutomation.Preferences)::OnErrorScreenShotFormat = [System.Drawing.Imaging.ImageFormat](System.Drawing.Imaging.ImageFormat)::Png;
# default: jpg
{code:powershell}
There is also the possibility to save screenshot on a successful run of a cmdlet. The format settings is independent from OnErrorScreenShot:
{code:powershell}
[UIAutomation.Preferences](UIAutomation.Preferences)::OnSuccessScreenShot
# default: $false
[UIAutomation.Preferences](UIAutomation.Preferences)::OnSuccessScreenShotFormat
# default: jpg
{code:powershell}
By default, screenshots are stored in the user's temp folder. Here is the setting:
{code:powershell}
[UIAutomation.Preferences](UIAutomation.Preferences)::ScreenShotFolder
{code:powershell}
Sometimes, we need controls' images to be saved without the red square. The following option hides or shows the square dring the time the module takes a screenshot:
{code:powershell}
[UIAutomation.Preferences](UIAutomation.Preferences)::HideHighlighterOnScreenShotTaking
# default: $true
{code:powershell}