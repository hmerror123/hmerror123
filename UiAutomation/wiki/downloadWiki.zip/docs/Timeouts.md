The UIAutomation module supports two type of timeout: the global and per cmdlet. The global timeout is default for all cmdlets that use timeout.
{code:powershell}
[UIAutomation.Preferences](UIAutomation.Preferences)::Timeout
# default: 5000
{code:powershell}
This setting means that by default Get-UIAWindow waits 5 seconds for a window and a Get-UIA{"[ControlType](ControlType)"} cmdlet waits 5 seconds for a control. Depending on how th system is loaded, cmdlet breaks the search after 5 seconds PLUS the time an Automation query takes.
You can set timeout on per cmdlet basis:
{code:powershell}
Get-UIAWindow -Name calc* -Timeout 10000 | Get-UIAButton -Name 1 -Seconds 3;
{code:powershell}
The -Seconds parameter works the same way as the -Timeout paramter (MSDN requires the -Timeout parametr to be measured in milliseconds).

There is also an automated timeout change. If a control is critical to your test, you can call a Get-UIA{"[ControlType](ControlType)"} cmdlet with the -IsCritical parameter. If this call fails, all the next calls of cmdlets will use the AfterFailTurboTimeout timeout that is shorter. Your tests will take less time during trying to click on wrong controls until a control will be caught. After this, the default (or the timeout you set as default) will be used again.
{code:powershell}
[UIAutomation.Preferences](UIAutomation.Preferences)::AfterFailTurboTimeout
# default: 2000
{code:powershell}