Interface ISupportsNavigation exposes methods to get an element from the upper, the lower and the same level of the Automation tree:
{code:powershell}
# returns the parent of a control
$element.NavigateToParent();

# returns the first child of a control
$element.NavigateToFirstChild();

# returns the last child of a control
$element.NavigateToLastChild();

# returns the next sibling of a control
$element.NavigateToNextSibling();

# returns the previous sibling of a control
$element.NavigateToPreviousSibling();
{code:powershell}