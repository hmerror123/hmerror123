Interface ISupportsSelectionItemPattern exposes three methods and two properties:
{code:powershell}
# selects and element. This method fits containers without multi-select.
$element.Select();

# These methods are for elements in a container that supports multi-select.
$element.AddToSelection();
$element.RemoveFromSelection();

# checking the state
$element.IsSelected

# getting the container
$parentContainer = $element.SelectionContainer
{code:powershell}