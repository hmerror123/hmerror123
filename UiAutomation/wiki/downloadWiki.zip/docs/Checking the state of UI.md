## Intro
It's a typical task - to determine the state of a window. Is a button available now? Will be the Next button enabled in four seconds? The majority of testers faced such questions, frequently or rarely.

The obvious way is as follows:
{code:powershell}
$ErrorActionPreference = [System.Management.Automation.ActionPreference](System.Management.Automation.ActionPreference)::SilentlyContinue
# we are seeking for the legendary "10" button in Calculator
$button = Start-Process calc -PassThru | Get-UIAWindow | Get-UIAButton -n 10
if ($null -ne $button) { Write-Host "not null" } else { Write-Host "null" }
{code:powershell}
Here we disabled pipeline interruption (enabled by default) and checked whether a control is null or isn't.

There is a better way (it's just my opinion. Practicians may argue):
{code:powershell}
$ErrorActionPreference = [System.Management.Automation.ActionPreference](System.Management.Automation.ActionPreference)::Continue;
Start-Process calc -PassThru | Get-UIAWindow | Test-UIAControlState -SearchCriteria @{controltype="button";name="10"}
{code:powershell}
There are two cmdlets for true/false answer, where question is "is there a control ... ?" (Test-UIAControlState) or "will be a control ... available in _Timeout_ seconds?" (Wait-UIAControlState).
## Test-UIAControlState
The Test-UIAControlState checks the state of a window. For example, we need to be sure that today there are buttons 1,3,5 on the Calculator form:
{code:powershell}
Start-Process calc -PassThru | Get-UIAWindow | Test-UIAControlState -SearchCriteria @{name="1"},@{name="3"},@{name="5"}
{code:powershell}
## Wait-UIAControlState
The Wait-UIAControlState cmdlet does exactly the same.
{code:powershell}
Start-Process calc -PassThru | Get-UIAWindow | Wait-UIAControlState -SearchCriteria @{name="1"},@{na
me="3"},@{name="5"} -Seconds 30
{code:powershell}
The difference is that this cmdlet is for dynamic applications like wizards or forms that paint controls by some external rule (an order was found in the DB, etc).

Note: the window you've gotten last is always the current. After successful Get-UIAWindow you can use Get-UIAButton without repeating Get-UIAWindow every time...
## Wait-UIAWindow
In some sutiations, it's necessary to wait until a window appears. It may be a slow UI, a slow host or a wizard, especially setup wizard. The Wait-UIAWindow cmdlet is an identical twin to the Get-UIAWindow cmdlet with the difference that the first returns $true when the second would return a window, and the first returns $false when the seconds would raise the exception.
Typical use of this cmdlet is in conditional constructions:
{code:powershell}
if (Wait-UIAWindow -pn calc -n **about** -Seconds 30) 
{ $true; }
else
{ $false; }
{code:powershell}
## Samples
{code:powershell}
# Verifies that a control(s) meet(s) provided conditions. Conditions is an array of Hashtables @{AutomationElement.propertyname=value}
ipmo C:\tests\UIAutomation.dll;
Write-Host "start the services.msc snap-in";
Stop-Process -Name mmc;
# now we open the Properties window
Start-Process services.msc -PassThru | Get-UIAWindow -p mmc | Get-UIADataItem -Name BranchCache | Invoke-UIAControlContextMenu | Get-UIAMenuItem -Name Properties | Invoke-UIAMenuItemClick;

# we are checking the OK button
Write-Host "checking the OK button (right)";
Get-UIAWindow -p mmc | Test-UIAControlState -SearchCriteria @{Name='OK'} -ver

# the Cancel button
Write-Host "checking the Cancel button (right)";
Get-UIAWindow -p mmc | Test-UIAControlState -SearchCriteria @{Name='Cancel'} #-ver

# the Apply button
Write-Host "checking IsEnabled (wrong IsEnabled because until any changes have been applied to the window, the Appy button is disabled)";
Get-UIAWindow -p mmc | Test-UIAControlState -SearchCriteria @{Name='Apply';IsEnabled=$true} #-ver

Write-Host "checking the OK and Cancel buttons (right)";
Get-UIAWindow -p mmc | Test-UIAControlState -SearchCriteria @{Name='OK'},@{Name='Cancel';IsEnabled=$true;IsOffscreen=$false} #-ver

Write-Host "checking the OK and Cancel buttons (wrong IsOffscreen)";
Get-UIAWindow -p mmc | Test-UIAControlState -SearchCriteria @{Name='OK'},@{Name='Cancel';IsEnabled=$false;IsOffscreen=$false} #-ver

Write-Host "checking the OK and Cancel buttons (wrong AutomationId)";
Get-UIAWindow -p mmc | Test-UIAControlState -SearchCriteria @{Name='OK';AutomationId='uuu'},@{Name='Cancel';IsEnabled=$true;IsOffscreen=$false} -ver

Write-Host "checking the OK and Cancel buttons (wrong parameter name, Exception will be raised)";
Get-UIAWindow -p mmc | Test-UIAControlState -SearchCriteria @{Name='OK'},@{Name='Cancel';IsEnabled=$true;IsOffscreen=$false;LocalizedConrolName='sss'} -ver

Write-Host "checking the OK and Cancel buttons (wrong LocalizedControlType)";
Get-UIAWindow -p mmc | Test-UIAControlState -SearchCriteria @{Name='OK'},@{Name='Cancel';IsEnabled=$true;IsOffscreen=$false;LocalizedControlType='sss'} -ver
{code:powershell}