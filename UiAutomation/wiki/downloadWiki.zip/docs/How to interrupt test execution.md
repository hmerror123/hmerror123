
This is about the -IsCritical parameter.