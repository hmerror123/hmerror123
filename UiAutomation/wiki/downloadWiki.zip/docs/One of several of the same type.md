If you have several controls with the same name, automation id and class and of the same type (ControlType), you may select one of them by index, if the order of controls is not going to change on the next run:
{code:powershell}
(Start-Process calc -PassThru | Get-UIAWindow | Get-UIAButton -n [1-3](1-3))[1](1) | Read-UIAControlName;
{code:powershell}