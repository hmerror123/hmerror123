MS UI Automation offers InvokePattern for controls that are considered 'click-ready'. If a control supports InvokePattern, we are aware whether the control accepted click on didn't. Use of this pattern is extremely easy:
{code:powershell}
Get-UIAWindow -pn calc | Get-UIAButton -Name 1 | Invoke-UIAButtonClick;
{code:powershell}
There is an option for output. By default, the Invoke-UIA{"[ControlType](ControlType)"}Click cmdlet returns the control(s) a successful click was performed against to the pipeline:
{code:powershell}
Get-UIAWindow -pn calc | Get-UIAButton -Name 1 | Invoke-UIAButtonClick | Read-UIAControlName;
{code:powershell}
Similarly, we can click on every numerical button, one by one:
{code:powershell}
Get-UIAWindow -pn calc | Get-UIAButton -Name [1-9](1-9) | Invoke-UIAButtonClick | Read-UIAControlName;
{code:powershell}
This behavior can be changed to output the true/false result ($true on success and $false on fail):
{code:powershell}
if (Get-UIAWindow -pn calc | Get-UIAButton -Name 1 | Invoke-UIAButtonClick -PassThru:$false) {
    # on successful click
}
{code:powershell}
Alternatively, an if condition could be built around null/not null state:
{code:powershell}
if ($null -ne (Get-UIAWindow -pn calc | Get-UIAButton -Name 1 | Invoke-UIAButtonClick)) {
    # on successful click
}
{code:powershell}
As it's said on the [InvokePattern](http://msdn.microsoft.com/en-us/library/ms523365.aspx) page, if a control supports another pattern with similar behavior (for example ExpandCollapsePattern for tree items or menu items), there is no InvokePattern provided.

Tags: ControlType.Window, ControlType.Button, InvokePattern