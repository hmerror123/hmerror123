[UIAutomation.Preferences](UIAutomation.Preferences)::AfterFailTurboTimeout
2000
[UIAutomation.Preferences](UIAutomation.Preferences)::ClickOnControlByCoordX
3
[UIAutomation.Preferences](UIAutomation.Preferences)::ClickOnControlByCoordY
3
[UIAutomation.Preferences](UIAutomation.Preferences)::DisableExactSearch
True
[UIAutomation.Preferences](UIAutomation.Preferences)::DisableWildCardSearch
False
[UIAutomation.Preferences](UIAutomation.Preferences)::DisableWin32Search
False
[UIAutomation.Preferences](UIAutomation.Preferences)::EveryCmdletAsTestResult

                                                                                                              IsPresent
                                                                                                              ---------
                                                                                                                  False


[UIAutomation.Preferences](UIAutomation.Preferences)::FailTestResultIfFailInTestSequence

                                                                                                              IsPresent
                                                                                                              ---------
                                                                                                                   True


[UIAutomation.Preferences](UIAutomation.Preferences)::FromCache
False
[UIAutomation.Preferences](UIAutomation.Preferences)::HideHighlighterOnScreenShotTaking
True
[UIAutomation.Preferences](UIAutomation.Preferences)::Highlight
True
[UIAutomation.Preferences](UIAutomation.Preferences)::HighlighterBorder
3
[UIAutomation.Preferences](UIAutomation.Preferences)::HighlighterBorderParent
5
[UIAutomation.Preferences](UIAutomation.Preferences)::HighlighterColor


R             : 255
G             : 0
B             : 0
A             : 255
IsKnownColor  : True
IsEmpty       : False
IsNamedColor  : True
IsSystemColor : False
Name          : Red



[UIAutomation.Preferences](UIAutomation.Preferences)::HighlighterColorParent


R             : 255
G             : 105
B             : 180
A             : 255
IsKnownColor  : True
IsEmpty       : False
IsNamedColor  : True
IsSystemColor : False
Name          : HotPink



[UIAutomation.Preferences](UIAutomation.Preferences)::HighlightParent
True
[UIAutomation.Preferences](UIAutomation.Preferences)::Log
True
[UIAutomation.Preferences](UIAutomation.Preferences)::LogPath
C:\Users\shuran\AppData\Local\Temp\UIAutomation.log
[UIAutomation.Preferences](UIAutomation.Preferences)::MaximumErrorCount
256
[UIAutomation.Preferences](UIAutomation.Preferences)::MaximumEventCount
256
[UIAutomation.Preferences](UIAutomation.Preferences)::OnClickDelay
0
[UIAutomation.Preferences](UIAutomation.Preferences)::OnErrorAction
[UIAutomation.Preferences](UIAutomation.Preferences)::OnErrorDelay
0
[UIAutomation.Preferences](UIAutomation.Preferences)::OnErrorScreenShot
True
[UIAutomation.Preferences](UIAutomation.Preferences)::OnErrorScreenShotFormat

Guid
----
b96b3cae-0728-11d3-9d7b-0000f81ef32e


[UIAutomation.Preferences](UIAutomation.Preferences)::OnSleepAction
[UIAutomation.Preferences](UIAutomation.Preferences)::OnSleepDelay
200
[UIAutomation.Preferences](UIAutomation.Preferences)::OnSuccessAction
[UIAutomation.Preferences](UIAutomation.Preferences)::OnSuccessDelay
0
[UIAutomation.Preferences](UIAutomation.Preferences)::OnSuccessScreenShot
False
[UIAutomation.Preferences](UIAutomation.Preferences)::OnSuccessScreenShotFormat

Guid
----
b96b3cae-0728-11d3-9d7b-0000f81ef32e


[UIAutomation.Preferences](UIAutomation.Preferences)::OnTranscriptIntervalAction
[UIAutomation.Preferences](UIAutomation.Preferences)::PerformWin32ClickOnFail
True
[UIAutomation.Preferences](UIAutomation.Preferences)::ScreenShotFolder
C:\Users\shuran\AppData\Local\Temp
[UIAutomation.Preferences](UIAutomation.Preferences)::ShowExecutionPlan
False
[UIAutomation.Preferences](UIAutomation.Preferences)::Timeout
5000
[UIAutomation.Preferences](UIAutomation.Preferences)::TranscriptInterval
200