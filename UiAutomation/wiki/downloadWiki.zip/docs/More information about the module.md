Documetation is being written, the live link to is here.

There's a series in the blog that may help you to see the automation as a whole learning task:

http://softwaretestingusingpowershell.com/category/daily-automation/

For things that you need to have explanation of, please write in the Wish List (like "describe Get-UIASomething cmdlet"), as well as any interesting features are worth being added to there. Editing is allowed to everybody.

Questions?

LinkedIn group "Software Testing Using PowerShell"

The project blog http://softwaretestingusingpowershell.com

Twitter @sft_testing_ps

email uiautomationAThotmailDOTcom