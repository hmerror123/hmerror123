Interface ISupportsGridItemPattern supports five properties:
{code:powershell}
# getting coordinates of an element
$element.GridRow
$element.GridColumn
$element.GridRowSpan
$element.GridColumnSpan

# getting the container an element is in
$parentContainer = $element.GridContainingGrid
{code:powershell}