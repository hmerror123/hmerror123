## TreeView: nodes with check boxes
Let's create a Windows Forms application with a TreeView control with several nodes, and set its CheckBoxes property to True:
![](TreeView_TreeViewTest001.jpg)
As the SelectItemPattern does nothing except changing the color of a node, the best way is to click to the left from a node:
{code:powershell}
Get-UIAWindow -pn treeviewtest | Get-UIATreeItem -Name Node5 | Invoke-UIAControlClick -X -10 -Y 3;
{code:powershell}
![](TreeView_TreeViewTest002.jpg)