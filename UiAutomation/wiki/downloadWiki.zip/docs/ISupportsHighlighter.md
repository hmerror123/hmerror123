Interface ISupportsHighlighter exposes one method:
{code:powershell}
# highlights an element
$element.Highlight();

# this is useful in such expressions
$element.NavigateToParent().Highlight();
{code:powershell}