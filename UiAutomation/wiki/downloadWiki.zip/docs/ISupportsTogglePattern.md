Interface ISupportsTogglePattern exposes one method and one property:
{code:powershell}
# changes state from On to Off and from Off to On
$element.Toggle();

# changes state to On ($true) or to Off ($false)
$element.Toggle($true);

# informs about the state
[System.Windows.Automation.ToggleState](System.Windows.Automation.ToggleState)$state = $element.ToggleState
{code:powershell}