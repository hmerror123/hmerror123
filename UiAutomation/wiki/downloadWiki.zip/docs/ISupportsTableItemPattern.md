Interface ISupportsTableItemPattern
{code:powershell}
$rowHeaderItems = $tableItem.GetRowHeaderItems();
$columnHeaderItems = $tableItem.GetColumnHeaderItems();
$tableItem.TableRow
$tableItem.TableColumn
$tableItem.TableRowSpan
$tableItem.TableColumnSpan
$parentContainer = $tableItem.TableContainingGrid
{code:powershell}