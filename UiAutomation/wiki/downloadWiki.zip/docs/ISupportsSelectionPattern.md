Interface ISupportsSelectionPattern
{code:powershell}
# returns selected elements
$elements = $grid.GetSelection();

# properties
$grid.CanSelectMultiple
$grid.IsSelectionRequired
{code:powershell}