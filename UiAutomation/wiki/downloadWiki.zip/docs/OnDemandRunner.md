This is a runner for PowerShell commands that works similarly to powerslim, excluding the need in FitNesse.
The idea behind was to run relatively 'expensive' (resource-consuming) modules only once per test suite.

## Where to use it
It is for low-performing virtual machines. For example, it may take up to ten seconds for a virtual machine in a high-load evironment to load the UIAutomation module.

## How it works
OnDemand runner is a script that monitors a file. When there is need to run a command, a test suite writes out a string a strings in a new file and copies the file in the place where the runner is waiting for an input.
