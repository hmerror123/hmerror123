The question "How do we know that the user or the test clicked?" can be answered easily. The answer is InvokedEvent.
For example, we need to know which numeric button of calc.exe have been clicked, and the number of click performed (a completely imaginary task):
{code:powershell}
[int](int)$global:clickCount = 0;
[string](string)$global:lastClickedButton;

Start-Process calc -PassThru | Get-UIAWindow | Get-UIAButton -n [1-9](1-9) | Register-UIAInvokedEvent -EventAction { $global:clickCount++; },{ param($src, $e) $global:lastClickedButton = $src.Current.Name; }; 
# the delay may be needed
sleep -Seconds 1;
Get-UIAButton -Name [1-9](1-9) | Invoke-UIAButtonClick;
# this delay is usually needed as events are relatively slow to be fired
sleep -Seconds 1;

# check the result
$global:clickCount
$global:lastClickedButton
{code:powershell}
The following [example](http://softwaretestingusingpowershell.com/2012/03/31/daily-automation-registering-users-clicks/) demonstrates how to create a simple custom log for clicks:
{code:powershell}
# use the Get-UIAControlDescendants cmdlet to collect all the visible buttons
# use the Register-UIAInvokedEvent cmdlet to assign an event action to each button
Start-Process calc -PassThru | `
Get-UIAWindow | `
Get-UIAControlDescendants -ControlType Button | `
Register-UIAInvokedEvent -EventAction {param($src) "$($src.Current.Name) clicked" >> $env:TEMP\calc.log;}
{code:powershell}

Tags: ControlType.Window, ControlType.Button, InvokePattern, InvokedEvent