The Control property consolidates several clicks and invocations, the following table provides code samples and mapping to cmdlets:

{code:powershell}
# $element | Invoke-UiaControlClick;
$element.Control.Click();

# $element | Invoke-UiaControlClick -X 10 -Y 10;
$element.Control.Click(10, 10);

# $element | Invoke-UiaControlClick -DoubleClick;
$element.Control.DoubleClick();

# $element | Invoke-UiaControlClick -DoubleClick -X 10 -Y 10;
$element.Control.DoubleClick(10, 10);

# $element | Invoke-UiaControlClick -RightClick;
$element.Control.RightClick();

# $element | Invoke-UiaControlClick -Alt;
$element.Control.AltClick();

# $element | Invoke-UiaControlClick -Shift;
$element.Control.ShiftClick();

# $element | Invoke-UiaControlClick -Ctrl;
$element.Control.CtrlClick();

# $element | Invoke-UiaControlContextMenu;
$element.Control.InvokeContextMenu();

# $element | Invoke-UiaControlContextMenu -X 10 -Y 10;
$element.Control.InvokeContextMenu(10, 10);
{code:powershell}