UIAutomationSpy is a tool that helps you write scripts, showing important information about a control your mouse is hovering over.

