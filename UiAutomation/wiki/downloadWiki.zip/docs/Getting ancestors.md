The Get-UIAControlAncestors cmdlet returns all the ancestry of a control (i.e., the parent, its parent, its respective parent, ...):
{code:powershell}
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAButton -Name 1 | Get-UIAControlAncestors | %{ Write-Host $_.Current.ControlType.ProgrammaticName $_.Current.Name $_.Current.AutomationId; };
{code:powershell}

Tags: TreeScope.Ancestors