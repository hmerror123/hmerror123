Sometimes, it's useful to search for a window or a top-level control (a pane or context menu) from the top of the Automation tree.
{code:powershell}
Get-UIADesktop | Get-UIAControlChildren | %{ $_ | Read-UIAControlName; $_ | Read-UIAControlAutomationId; }
{code:powershell}
The above script read names and automationIds of all top-level objects that are available, like menus and panes (TaskBar, etc).

Working with Metro UI, it's even a must to start from the top as Metro UI applications grow from non-Metro UI top of the Automation tree:
{code:powershell}
# from BGShell or UIARunner
Get-UIADesktop;
Show-UIAMetroStartScreen;
Get-UIAListItem Music;
{code:powershell}