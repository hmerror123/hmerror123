There is a [post](http://softwaretestingusingpowershell.com/2012/06/04/daily-automation-hunting-down-system-tooltips/).
As an additional example, we are going to report which tooltips have been opened since our sample had been run. We register TooltipOpenedEvent on the desktop object:
{code:powershell}
$elements = New-Object System.Collections.ArrayList;
Get-UIADesktop | Register-UIAToolTipOpenedEvent -EventAction { param($src, $e) $elements.Add($src.Current.Name); };
{code:powershell}
After hovering over items in Taskbar
![](TooltipOpened and TooltipClosed_TooltipOpenedEvent001.jpg)
my output was
"Windows PowerShell ISE"
"You are running out of disk space on Podcasts (G:).
Click here to see if you can free space on this drive."
"You are running out of disk space on Local Disk (E:).
Click here to see if you can free space on this drive."
"Windows PowerShell ISE"

Similarly, we can add registration for TooltipClosedEvent. In the script below, we add registration for both opening and closing tooltip events. The scripts fills the array list, allowing us to match opening and closing events by their windows' handles:
{code:powershell}
$elements = New-Object System.Collections.ArrayList;
Get-UIADesktop | Register-UIAToolTipOpenedEvent -EventAction { param($src, $e) $elements.Add("opened:"); $elements.Add($src.Current.Name); $elements.Add($src.Current.NativeWindowhandle); }
Get-UIADesktop | Register-UIAToolTipClosedEvent -EventAction { param($src, $e) $elements.Add("closed:"); $elements.Add($src.Current.NativeWindowhandle); }
{code:powershell}

Tags: TooltipOpenedEvent, TooltipClosedEvent