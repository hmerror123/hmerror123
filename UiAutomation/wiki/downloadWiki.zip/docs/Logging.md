By default, the module writes all data that could be seen in the verbose output in the log file.
The Log parameter turns on or off logging:
{code:powershell}
[UIAutomation.Preferences](UIAutomation.Preferences)::Log
# default: $true
{code:powershell}
You can set the name and path to the log file:
{code:powershell}
[UIAutomation.Preferences](UIAutomation.Preferences)::LogPath
# default: $env:USERPROFILE\AppData\Local\Temp\UIAutomation.log
{code:powershell}