The UIAutomation module supports several types of search.
[Straightforward (native) search](Straightforward-(native)-search)
[Search in most used properties](Search-in-most-used-properties)
[Wild card search](Wild-card-search) TBD
[Win32 search](Win32-search) TBD
[Multi-property search](Multi-property-search) TBD