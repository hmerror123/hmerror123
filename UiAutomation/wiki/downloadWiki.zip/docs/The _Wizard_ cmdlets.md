[Introduction to **Wizard** cmdlets](Introduction-to-__Wizard__-cmdlets) in progress
[How to declare wizard code](How-to-declare-wizard-code) TBD
[How to run the code you declared](How-to-run-the-code-you-declared) TBD
[How to parameterize your wizard's code](How-to-parameterize-your-wizard's-code) TBD
[How to change declared code on the fly](How-to-change-declared-code-on-the-fly) TBD
[How to return to the declared code](How-to-return-to-the-declared-code) TBD
[the Add Printer wizard sample](the-Add-Printer-wizard-sample)
