By default, the UIAutomation module provides you with two highlighters (squares): one for an element that cmdlet returns and one for its parent.
{code:powershell}
# When a screenshot is being taken automatically, hides the highlighter
[UIAutomation.Preferences](UIAutomation.Preferences)::HideHighlighterOnScreenShotTaking
# default: $true
{code:powershell}
The following three parameters relate to highlighting of a control or controls that cmdlet returns.
{code:powershell}
# highlighter for the element returned
[UIAutomation.Preferences](UIAutomation.Preferences)::Highlight
# default: $true
{code:powershell}
{code:powershell}
[UIAutomation.Preferences](UIAutomation.Preferences)::HighlighterBorder
# default: 3
{code:powershell}
{code:powershell}
[UIAutomation.Preferences](UIAutomation.Preferences)::HighlighterColor
# default: [System.Drawing.Color](System.Drawing.Color)::Red
{code:powershell}
The same parameters are provided for parent's keys.
{code:powershell}
# highlighter for the element's parent returned
[UIAutomation.Preferences](UIAutomation.Preferences)::HighlightParent
# default: $true
{code:powershell}
{code:powershell}
[UIAutomation.Preferences](UIAutomation.Preferences)::HighlighterBorderParent
# default: 5
{code:powershell}
{code:powershell}
[UIAutomation.Preferences](UIAutomation.Preferences)::HighlighterColorParent
# default: [System.Drawing.Color](System.Drawing.Color)::HotPink
{code:powershell}
