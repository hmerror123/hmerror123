Module settings can be seen by issuing the following cmdlet:
{code:powershell}
Show-UIAModuleSettings
{code:powershell}

[Highlighter](Highlighter)
[Screenshot taking](Screenshot-taking) TBD
[Logging](Logging)
[Test result generation](Test-result-generation) TBD
[Actions](Actions) TBD
[Timeouts](Timeouts) TBD
[Delays](Delays) TBD


[Other](Other) TBD