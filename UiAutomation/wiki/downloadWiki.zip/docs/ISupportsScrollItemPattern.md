Interface ISupportsScrollItemPattern exposes one method:
{code:powershell}
# brings an element to the visible area
$element.ScrollIntoView();
{code:powershell}