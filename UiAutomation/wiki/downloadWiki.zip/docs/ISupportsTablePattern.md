Interface ISupportsTablePattern exposes two methods and three properties:
{code:powershell}
# return headers if present
$rowHeaders = $element.GetRowHeaders();
$columnHeaders = $element.GetColumnHeaders();

# counters
$element.TableRowCount
$element.TableColumnCount

[System.Windows.Automation.RowOrColumnMajor](System.Windows.Automation.RowOrColumnMajor)$major = $element.RowOrColumnMajor
{code:powershell}