Installing of an [uiAccess applicaiton](http://msdn.microsoft.com/en-us/library/windows/desktop/bb756929.aspx) is not so easy and requires several steps to take.
## Downloading the package
_Goal: obtain the irght package_
First of all, download the right package. Go to the [project page](http://uiautomation.codeplex.com/) and click the Downloads tab:
![](Installation for Metro UI testing_installing_the_module_0001.jpg)
There, you need to download the package that is called as ‘UIAutomation X.Y.Z for Metro testing’ (of the latest version, of cource):
![](Installation for Metro UI testing_installing_the_module_0002.jpg)
Download the package with name like ‘UIAutomation.X.Y.Z.for.Metro.testing.zip’.
## Unblocking the package (optional)
You may want to unblock the package itself (in case that your operating system's settings prevent you from taking the following steps). This does not unblock the content.
![](Installation for Metro UI testing_installing_the_module_0002_1.jpg)
The properties of an archive that was unblocked look like:
![](Installation for Metro UI testing_installing_the_module_0002_2.jpg)
## Unpacking
_Goal: get files_
Open the package. Don’t put the content directly to the %ProgramFiles% folder! It won’t work. Security has been tightened even more (and it’s a good news for us), so that we need to do some preparations. 
Open the package where it was saved (supposedly, in your Downloads folder):
![](Installation for Metro UI testing_installing_the_module_0003.jpg)
Unpack the zip into your user’s folder, for example, Documents. I created the folder ‘Metro’ and paste the files to there. Open properties of dlls:
![](Installation for Metro UI testing_installing_the_module_0004.jpg)
Now, you need to unblock the binaries one by one:
![](Installation for Metro UI testing_installing_the_module_0005.jpg)
## Putting module files into a secure location
_Goal: put files from the package to a place where they would work unless you have changed the policy_
Eventually, you can copy all the files to a folder within the ‘Program Files’ hierarchy (one of possible secure locations, called [here](http://msdn.microsoft.com/en-us/library/windows/desktop/bb756929.aspx) protected locations). If you had not unblocked the binaries, or tried to unblock in the ‘Program Files’ folder, your output in PowerShell console would look like that:
![](Installation for Metro UI testing_installing_the_module_00061.jpg)
If you did all I wrote above, you output will be much cleaner:
![](Installation for Metro UI testing_installing_the_module_0007.jpg)
## Importing the certificate
_Goal: as only applications signed with recognizable certificate could work with uiAccess, you need to import the certificate that shipped with the package_
With the package, you've got a certificate. You need to install it. Alternatively, you can sign UIAutomationSpy.exe with the certificate you possibly have.
If you have no your own certificate, below are screenshots showing how to use the certificate from the package. Run certmgr, for example, from cmd.exe, or from the Start Screen
![](Installation for Metro UI testing_importing_the_certificate_001.jpg)
and follow the pictures:
![](Installation for Metro UI testing_importing_the_certificate_01.jpg)
![](Installation for Metro UI testing_importing_the_certificate_02.jpg)
![](Installation for Metro UI testing_importing_the_certificate_03.jpg)
![](Installation for Metro UI testing_importing_the_certificate_04.jpg)
![](Installation for Metro UI testing_importing_the_certificate_05.jpg)
![](Installation for Metro UI testing_importing_the_certificate_06.jpg)
![](Installation for Metro UI testing_importing_the_certificate_07.jpg)
## Changing the policy (as alternative to using a secure location)
_Goal: to work with module files where you'd like to_
After you installed the certificate and the application in the secure location (you might set the policy not to require this if you’d like to), you can run the application. If you want to change the policy, run gpedit.msc, for example, from the Start screen
![](Installation for Metro UI testing_importing_the_certificate_002.jpg)
and set the following setting:
![](Installation for Metro UI testing_importing_the_certificate_003.jpg)
![](Installation for Metro UI testing_importing_the_certificate_004.jpg)
After you’ve finished, reload policies:
![](Installation for Metro UI testing_importing_the_certificate_005.jpg)
For the first test, just run the application, agree with UAC and manually run the Start screen by pressing the Win button. Now you should see something like on the picture below:
![](Installation for Metro UI testing_importing_the_certificate_09.jpg)
On the picture, UIAutomationSpy shows the code for the Mail tile. It is bordered with the red rectangle. All that I’d like to offer is to explore tiles:
![](Installation for Metro UI testing_importing_the_certificate_10.jpg)
This is a text box, Edit in terms of UIAutomation.