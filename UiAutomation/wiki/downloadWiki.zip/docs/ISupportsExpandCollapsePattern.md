Interface ISupportsExpandCollapsePattern supports two methods and determines the state of a control:
{code:powershell}
# expanding an element (tree node, menu item, etc)
$element.Expand();

# collapsing an element
$element.Collapse();

# getting element's state
[System.Windows.Automation.ExpandCollapseState](System.Windows.Automation.ExpandCollapseState)$state = $lement.ExpandCollapseState;
{code:powershell}