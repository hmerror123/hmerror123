If a control does not support InvokePattern, it is not a big problem. We have for this purpose the Invoke-UIAcontrolClick cmdlet:
{code:powershell}
Get-UIAWindow -pn calc | Get-UIAButton -Name 1 | Invoke-UIAControlClick;
{code:powershell}
Traditionally, the Invoke-UIAControlClick cmdlet supports a number of input controls:
{code:powershell}
Get-UIAWindow -pn calc | Get-UIAButton -Name [1-9](1-9) | Invoke-UIAControlClick;
{code:powershell}
This cmdlet pipelines the input to the output, if no errors raised:
{code:powershell}
Get-UIAWindow -pn calc | Get-UIAButton -Name [1-9](1-9) | Invoke-UIAControlClick | Read-UIAControlName;
{code:powershell}
![](Click via Win32 API_InvokeUIAControlClick001.jpg)

The Invoke-UIAControlClick cmdlet uses Win32 API calls (SendMessage/PostMessage, for example) working only with controls that have handles. However, the Invoke-UIAControlClick cmdlet accepts any AutomationElement, with or without a handle. How does this work? The cmdlet accepts a control, and if the input control has handle, the cmdlet hits the geometrical center of the control.
If a control has no handle, the cmdlet gets its parent, if there is no handle too, its respective parent unless a control with handle is found (even if it is the process's window). After that the cmdlet calculates the position that corresponds to the geometrical center of the input control and hits there. So works click on any control with the API call that works only with handles.

The Invoke-UIAControlClick cmdlet can also be used in conditional statements, but we should remember that the SendMessage call does not return a value we could use as a result flag. Thus, the $true result means only that no network errors occured, or the system has not been shut down, etc.
{code:powershell}
# we are not sure that click was successful
if (Get-UIAWindow -pn calc | Get-UIAButton -Name 1 | Invoke-UIAControlClick -PassThru:$false) {
    # on probably successful click
}
{code:powershell}
or
{code:powershell}
# the assume that the click was successful
if ($null -ne (Get-UIAWindow -pn calc | Get-UIAButton -Name 1 | Invoke-UIAControlClick)) {
    # on probably successful click
}
{code:powershell}

Tags: ControlType.Window, ControlType.Button, SendMessage