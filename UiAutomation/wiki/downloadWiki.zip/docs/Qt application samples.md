[VLC Player](VLC-Player) TBD
please suggest more from [Free](http://qt-apps.org) or [Paid](http://qt-prop.org) lists.