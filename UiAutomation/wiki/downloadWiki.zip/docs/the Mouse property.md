The Mouse property exposes methods that the Mouse object of InputSimulator offers. The object model tries to set focus on an element of the interest and applies to it one of the following methods:
{code:powershell}
$element.Mouse.HorizontalScroll(int scrollAmountInClicks);
$element.Mouse.LeftButtonClick();
$element.Mouse.LeftButtonDoubleClick();
$element.Mouse.LeftButtonDown();
$element.Mouse.LeftButtonUp();
$element.Mouse.MoveMouseBy(int pixelDeltaX, int pixelDeltaY);
$element.Mouse.MoveMouseTo(double absoluteX, double absoluteY);
$element.Mouse.MoveMouseToPositionOnVirtualDesktop(double absoluteX, double absoluteY);
$element.Mouse.RightButtonClick();
$element.Mouse.RightButtonDoubleClick();
$element.Mouse.RightButtonDown();
$element.Mouse.RightButtonUp();
$element.Mouse.Sleep(int milliseconds);
$element.Mouse.Sleep(TimeSpan timeout);
$element.Mouse.VerticalScroll(int scrollAmountInClicks);
$element.Mouse.XButtonClick(int buttonId);
$element.Mouse.XButtonDoubleClick(int buttonId);
$element.Mouse.XButtonDown(int buttonId);
$element.Mouse.XButtonUp(int buttonId);
{code:powershell}