The Get-UIAControlDescendants cmdlet returns all controls that are below the control that was pipelined into the cmdlet:
{code:powershell}
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAControlDescendants | %{ Write-Host $_.Current.ControlType.ProgrammaticName $_.Current.Name $_.Current.AutomationId; }
{code:powershell}
This way we can get only Buttons:
{code:powershell}
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAControlDescendants -ControlType Button | %{ Write-Host $_.Current.ControlType.ProgrammaticName $_.Current.Name $_.Current.AutomationId; }
{code:powershell}
Below are examples how to get a control by name (this works similarly to the Get-UIAButton cmdlet). The difference is that the Get-UIAControlDescendants cmdlet works via the FindAll method, whereas {"Get-UIA[ControlType](ControlType)"} cmdlets analyze properties and apply wildcards.
{code:powershell}
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAControlDescendants -Name 1 | %{ Write-Host $_.Current.ControlType.ProgrammaticName $_.Current.Name $_.Current.AutomationId; }
{code:powershell}
{code:powershell}
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAControlDescendants -Name Add | %{ Write-Host $_.Current.ControlType.ProgrammaticName $_.Current.Name $_.Current.AutomationId; }
{code:powershell}

Tags: TreeScope.Ancestors