### 0.8.7
1) more API just from command line to support for cmdletless mode like
{code:powershell}
(Get-UiaButton ...).Invoke() or (Get-UiaTreeItem).Expand()
{code:powershell}
, or
{code:powershell}
# types 1110
$btn = Start-Process calc -PassThru | Get-UiaWindow | Get-UiaButton 1
$btn.Invoke().Invoke().Invoke().NavigateToNextSibling().Invoke().Highlight();
{code:powershell}
Each element you get from cmdlets exposes properties and methods accordingly to patterns it supports. This allows you to perform less calls to the Automation tree, to shorten and simplify your code. For example, after one call like
{code:powershell}
$wnd = Get-UiaWindow ...; # your code to move the window looks like
if ($window.CanMove) $wnd.Move(1000, 500) # or even simply
$wnd.Move(1000, 500) # as the object model hides the unsupported. (available)
{code:powershell}
2) support for regular expressions when 'Get-'ting controls with the -Regex parameter (available)
3) bug fixes (available)
4) keyboard cmdlets
5) renewed Invoke-UiaWizard cmdlet (available)
6) renewed Invoke-UiaControlContextMenu cmdlet and the $element.Control.InvokeContextMenu method (available)
7) new logging (available)

### 0.8.6
1) recursive search for child windows (available)
2) getting a window with specific control(s) (available)
3) improvements to wizard cmdlets (available, with a known issue)
4) the DateTimePicker cmdlet by Crowcz and a couple of others (available)
5) new cmdlets for radio buttons (available)
6) new banner cmdlets and parameters (available).
