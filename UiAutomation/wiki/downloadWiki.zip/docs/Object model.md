### Introduction
Automation elements now support a dynamic object model. This means that if an element support pattern N, it also exposes properties and method for the pattern N.
Properties provides us with read-only information.
If a method does not return string or other information, it returns the object it was called on, i.e. supports chaining or pipelining ('chaining methods' is a term used in several staticly-typed languages, for example, C#. As a reference to terms 'chaining' and 'pipelining' you may look in this [Skeet's book](http://www.amazon.com/C-Depth-3rd-Jon-Skeet/dp/161729134X/ref=sr_1_1?s=books&ie=UTF8&qid=1387828078&sr=1-1&keywords=jon+skeet&tag=s601000020-20)):
{code:powershell}
(Start-Process calc -PassThru | Get-UiaWindow | Get-UiaButton 1).Invoke().NavigateToNextSibling().Invoke().Highlight();
{code:powershell}
Microsoft provides a [map](http://msdn.microsoft.com/en-us/library/ms750574(v=vs.110).aspx) of patterns to control types. However, accordingly to my observation, situations when a control supports all recommended patterns are rare, especially if a software under test is from a 3rd party vendor.
This is cured partially by attaching Click methods to elements.

### Common interfaces
Automation elements always support three interfaces:
[ISupportsNavigation](ISupportsNavigation)
[ISupportsHighlighter](ISupportsHighlighter)
[ISupportsControlPattern](ISupportsControlPattern)
[ISupportsConversion](ISupportsConversion) TBD
[ISupportsExport](ISupportsExport) TBD
[ISupportsRefresh](ISupportsRefresh)
Notice that clicks are available whether or not the element really supports InvokePattern.

### Specific interfaces
[ISupportsDockPattern](ISupportsDockPattern)
[ISupportsExpandCollapsePattern](ISupportsExpandCollapsePattern)
[ISupportsGridItemPattern](ISupportsGridItemPattern)
[ISupportsGridPattern](ISupportsGridPattern)
[ISupportsInvokePattern](ISupportsInvokePattern)
[ISupportsRangeValuePattern](ISupportsRangeValuePattern)
[ISupportsScrollItemPattern](ISupportsScrollItemPattern)
[ISupportsScrollPattern](ISupportsScrollPattern)
[ISupportsSelectionItemPattern](ISupportsSelectionItemPattern)
[ISupportsSelectionPattern](ISupportsSelectionPattern)
[ISupportsTableItemPattern](ISupportsTableItemPattern)
[ISupportsTablePattern](ISupportsTablePattern)
[ISupportsTextPattern](ISupportsTextPattern)
[ISupportsTogglePattern](ISupportsTogglePattern)
[ISupportsTransformPattern](ISupportsTransformPattern)
[ISupportsValuePattern](ISupportsValuePattern)
[ISupportsWindowPattern](ISupportsWindowPattern)

### Integrated search
[Common information about integrated searches](Common-information-about-integrated-searches)
[the Children property](the-Children-property) TBD
[the Descendants property](the-Descendants-property)

### Input simulation
[Common information about input simulation](Common-information-about-input-simulation) TBD
[the Control property](the-Control-property)
[the Keyboard property](the-Keyboard-property)
[the Mouse property](the-Mouse-property)
[the Touch property](the-Touch-property) TBD

