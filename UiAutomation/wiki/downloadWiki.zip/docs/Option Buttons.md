Let's turn calc.exe in the Programmer mode:
{code:powershell}
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAMenuItem -Name View | Invoke-UIAMenuItemExpand | Get-UIAMenuItem -Name Programmer | Invoke-UIAMenuItemClick;
{code:powershell}
![](Option Buttons_ProgrammerMode001.jpg)
## Getting the selected item
To check whether a radio button is selected or isn't:
{code:powershell}
Get-UIAWindow -pn calc | Get-UIARadioButton -Name Dec | Get-UIARadioButtonSelectionItemState;
{code:powershell}
Though it's normal to know which of radio buttons is selected in a particular test, sometimes we need to know which one gets selected by some external reason, for example, human interaction or program's internal logic.
The result heavily depends on what the container of radio button is. For test, we created a simple Windows Forms application with four types of container: a group box, a tab item, a panel, and a image box:
![](Option Buttons_RadioButtonTest001.jpg)
Of those four containers, only group box, the control natively dedicated to group elements, including radio buttons, provides SelectionPattern. As the [default control to patterns mapping](http://msdn.microsoft.com/en-us/library/ms750574.aspx#control_mapping_clients) does not offer SelectionPattern for group box control, there is no such cmdlet: Get-UIAGroupSelection. However, for ControlType.Custom we created all types of cmdlets, so that one of them is what we can use here:
{code:powershell}
Get-UIAWindow -pn optionbuttontest | Get-UIAGroup | Get-UIACustomSelection;
{code:powershell}
There is a strange asymmetry: controls support SelectionItemPattern and, at the same time, their container does not support SelectionPattern. It's not a problem for our module, of course, let's use what we have, SelectionItemPattern, as a solution. There is a special cmdlet for that, Get-UIASelectedItem, that receives items and returns only those which are selected. We could feed it with all radio buttons the window has as well as with any amounts of radio buttons:
![](Option Buttons_RadioButtonTest002.jpg)
{code:powershell}
# all radio buttons
Get-UIAWindow -pn optionbuttontest | Get-UIARadioButton | Get-UIASelectedItem | Read-UIAControlName
# the result is:
# radioButton7
# radioButton6
# radioButton3
# radioButton2

Get-UIAWindow -pn optionbuttontest | Get-UIARadioButton -Name *[1-2](1-2) | Get-UIASelectedItem | Read-UIAControlName
# radioButton2

Get-UIAWindow -pn optionbuttontest | Get-UIARadioButton -Name *[3-4](3-4) | Get-UIASelectedItem | Read-UIAControlName
# radioButton3

Get-UIAWindow -pn optionbuttontest | Get-UIARadioButton -Name *[5-6](5-6) | Get-UIASelectedItem | Read-UIAControlName
# radioButton6

Get-UIAWindow -pn optionbuttontest | Get-UIARadioButton -Name *[7-8](7-8) | Get-UIASelectedItem | Read-UIAControlName
# radioButton7
{code:powershell}
## Setting selection
{code:powershell}
Get-UIAWindow -pn calc | Get-UIARadioButton -Name bin | Invoke-UIARadioButtonSelectItem -ItemName bin;
{code:powershell}
{code:powershell}
Get-UIAWindow -pn calc | Get-UIARadioButton -Name byte | Invoke-UIARadioButtonSelectItem -ItemName byte;
{code:powershell}
![](Option Buttons_ProgrammerMode002.jpg)
Tags: ControlType.Window, ControlType.RadioButton, AutomationElement, SelectItemPattern