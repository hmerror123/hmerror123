[UIAutomation.Preferences](UIAutomation.Preferences)::OnClickDelay
0
[UIAutomation.Preferences](UIAutomation.Preferences)::OnErrorDelay
0
[UIAutomation.Preferences](UIAutomation.Preferences)::OnSleepDelay
200
[UIAutomation.Preferences](UIAutomation.Preferences)::OnSuccessDelay
0