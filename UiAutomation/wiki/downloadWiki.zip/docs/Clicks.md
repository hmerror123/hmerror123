[Click via InvokePattern](Click-via-InvokePattern)
[Click via Win32 API](Click-via-Win32-API)
[Click on position](Click-on-position)
[Double click](Double-click) TBD
[Right click](Right-click) TBD
[Mid click](Mid-click) TBD
[X-clicks](X-clicks) TBD
[Moving the cursor](Moving-the-cursor) TBD