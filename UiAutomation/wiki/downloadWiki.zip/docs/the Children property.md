The Children property returns all child controls of the selected type down the control the property is called on:
{code:powershell}

{code:powershell}
