## Performing a click
To click on a control, use a cmdlet with verb 'Invoke' and part of noun 'Click':
{code:powershell}
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAButton -Name 1 | Invoke-UIAButtonClick;
{code:powershell}
In the sample above we clicked on the button 1. Now, we click on butttons 1,2, and 3:
{code:powershell}
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAButton -Name [1-3](1-3) | Invoke-UIAButtonClick;
{code:powershell}
How does this work? The Get-UIAButton returns three controls with names 1, 2, and 3. The Invoke-UIAButtonClick cmdlet receives three controls and clicks on each.

In versions prior to 0.8.3, to click on a control that does not support InvokePattern, we should use the Invoke-UIAControlClick cmdlet:
{code:powershell}
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAButton -Name [1-3](1-3) | Invoke-UIAControlClick;
{code:powershell}
## Reading and writing text
For these examples, let's turn Calculator in the Mortgage mode:
![](Invoking actions on controls_ReadingWritingText001.jpg)
{code:powershell}
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAMenuItem -Name View | Invoke-UIAMenuItemExpand | Get-UIAMenuItem -Name Worksheets | Move-UIACursor -X 3 -Y 3 | Get-UIAMenuItem -Name Mortgage | Invoke-UIAMenuItemClick;
{code:powershell}
### Writing text
We will now write numbers into Edit elements, supposing that Calculator is running and prepared as shown above.
{code:powershell}
Get-UIAWindow -pn calc;
Get-UIAEdit -Name Purchase*price | Set-UIAEditText -Text 100;
Get-UIAEdit -Name Down*payment | Set-UIAEditText -Text 10;
Get-UIAEdit -Name Term**years** | Set-UIAEditText -Text 10;
Get-UIAEdit -Name Interest**rate** | Set-UIAEditText -Text 2;
Get-UIAButton -Name Calc* | Invoke-UIAButtonClick;
{code:powershell}
![](Invoking actions on controls_ReadingWritingText002.jpg)
### Getting text
{code:powershell}
Get-UIAWindow -pn calc;
Get-UIAEdit -Name Monthly*payment | Get-UIAEditText;
{code:powershell}
## Selecting an item

{code:powershell}

{code:powershell}

## Scrolling an item
ScrollItemPattern helps much if a control of interest is hidden. Here we run services.msc (via Run as Administrator or under credentials of an administrative account), on a Windows 7 box, where the BranchCache service row is out of the application screen:
{code:powershell}
Start-Process services.msc -PassThru | Get-UIAWindow | Get-UIADataGrid | Get-UIADataItem -Name BranchCache | Invoke-UIADataItemScrollItem | Invoke-UIAControlContextMenu | Get-UIAMenuItem -Name Properties | Invoke-UIAMenuItemClick;
{code:powershell}

Tags: ControlType.Window, ControlType.Button, InvokePattern, SendMessage, ExpandCollapsePattern, ControlType.MenuItem, move cursor, ScrollItemPattern