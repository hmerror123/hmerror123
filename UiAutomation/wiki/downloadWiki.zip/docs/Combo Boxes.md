For our experiments we will use calc.exe put in the Mortgage mode:
{code:powershell}
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAMenuItem -Name View | Invoke-UIAMenuItemExpand | Get-UIAMenuItem -Name Worksheets | Move-UIACursor -X 3 -Y 3 | Get-UIAMenuItem -Name Mortgage | Invoke-UIAMenuItemClick;
{code:powershell}
![](Combo Boxes_ReadingWritingText003.jpg)
## Getting the full list of items
The only things you need to know here is that items in combo box are of type ListItem:
{code:powershell}
Get-UIAWindow -pn calc | Get-UIAComboBox | Get-UIAListItem | Read-UIAControlName;
{code:powershell}
The Read-UIAControlName cmdlet is here for readability only: if you need to get AutomationElements of items, yor code would be:
{code:powershell}
Get-UIAWindow -pn calc | Get-UIAComboBox | Get-UIAListItem;
{code:powershell}
![](Combo Boxes_ReadingWritingText004.jpg)
## Getting the selected item
{code:powershell}
Get-UIAWindow -pn calc | Get-UIAComboBox | Get-UIAComboBoxSelection | Read-UIAControlName;
{code:powershell}
## Selecting an item
To select an item in combo box, we first need to get the item we want to select and, second, apply SelectItemPattern to the item. SelectItemPattern requires the name, so that we need to use the name twice:
{code:powershell}
Get-UIAWindow -pn calc | Get-UIAComboBox | Get-UIAListItem -Name term* | Invoke-UIAListItemSelectItem -ItemName term*
{code:powershell}
![](Combo Boxes_ReadingWritingText005.jpg)

Tags: ControlType.Window, ControlType.MenuItem, ControlType.ComboBox, InvokePattern, ExpandCollapsePattern, move cursor, SelectionPattern, ControlType.ListItem, AutomationElement, SelectItemPattern