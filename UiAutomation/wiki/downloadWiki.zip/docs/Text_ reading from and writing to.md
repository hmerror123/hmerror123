Text patterns:
[ValuePattern](ValuePattern)
[TextPattern](TextPattern) TBD
[SendMessage](SendMessage) TBD
[SendKeys](SendKeys)

Controls:
[Edit (TextBox)](Edit-(TextBox)) TBD