There are six event indicating that the structure of Automation tree has been changed. These six events can be chosed as parameters of the Register-UIAStructureChangedEvent cmdlet:
{code:powershell}
Register-UIAStructureChangedEvent -ChildAdded -ChildRemoved -ChildrenInvalidated -ChildrenBulkAdded -ChildrenBulkRemoved -ChildrenReordered
{code:powershell}
In the following sample, we register a StructureChangedEvent, after that (no code provided) we perform manual or programmatic actions with GUI, and, finally, obtain the results list.
{code:powershell}
$global:annals = New-Object System.Collections.ArrayList;
Start-Process calc -PassThru | Get-UIAWindow | Register-UIAStructureChangedEvent -ChildrenBulkAdded -ChildAdded -ChildRemoved -ChildrenReordered -EventAction { param($src, $e) $global:annals.Add($src.Current.Name); $global:annals.Add($e.StructureChangeType); };

# perform manual or programmatic actions like show/hide worksheets or change mode

# display which event have been caught
$global:annals;
{code:powershell}