.
Show-UIAExecutionPlan
[UIAutomation.Preferences](UIAutomation.Preferences)::ShowExecutionPlan