actions

[UIAutomation.Preferences](UIAutomation.Preferences)::OnErrorAction
[UIAutomation.Preferences](UIAutomation.Preferences)::OnSleepAction
[UIAutomation.Preferences](UIAutomation.Preferences)::OnSuccessAction
[UIAutomation.Preferences](UIAutomation.Preferences)::OnTranscriptIntervalAction
