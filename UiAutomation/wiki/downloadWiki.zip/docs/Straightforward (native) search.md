This type of search requires the least learning curve: you only need to have the exact phrase that is displayed on a control:
{code:powershell}
# run an application's instance and prepare it for search
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAButton -Name [1-3](1-3) | Invoke-UIAButtonClick;
# perform search for a control
Get-UIAText 123;
{code:powershell}
This types of search investigates into values containing in the following properties:
* Name
* AutomationId
* Class (ClassName)
* Value (ValuePattern.Value)
If any of properties of the control contains the string given, the control is outputted.

Alternatively, you can use the name of parameter:
{code:powershell}
# run an application's instance and prepare it for search
Start-Process calc -PassThru | Get-UIAWindow | Get-UIAButton -Name [1-3](1-3) | Invoke-UIAButtonClick;
# perform search for a control
Get-UIAText -ContainsText 123;
{code:powershell}

Tags: ControlType.Window, ControlType.Button, ValuePattern.Pattern.Value, InvokePattern