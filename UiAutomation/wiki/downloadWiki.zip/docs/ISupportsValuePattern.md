Interface ISupportsValuePattern exposes two properties:
{code:powershell}
$element.IsReadOnly
$element.Value = "333";
$value = $element.Value
{code:powershell}